const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const db = new sqlite3.Database("users.db");

// Create the users table
db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)");

    const saltRounds = 10;

    const users = [
        { username: "user1", password: "password1" },
        { username: "user2", password: "password2" },
        { username: "admin", password: "adminpass" }
    ];

    // Function to hash a password and insert the user
    const insertUser = (user) => {
        return new Promise((resolve, reject) => {
            bcrypt.hash(user.password, saltRounds, (err, hashedPassword) => {
                if (err) {
                    reject(err);
                    return;
                }

                db.run(
                    "INSERT INTO users (username, password) VALUES (?, ?)",
                    [user.username, hashedPassword],
                    (err) => {
                        if (err) {
                            reject(err);
                        } else {
                            resolve();
                        }
                    }
                );
            });
        });
    };

    const insertAllUsers = async () => {
        for (const user of users) {
            try {
                await insertUser(user);
                console.log(`User ${user.username} inserted successfully.`);
            } catch (err) {
                console.error(`Error inserting user ${user.username}:`, err);
            }
        }
    };

    insertAllUsers();

    // Create the reported_emails table (regular emails table)
    db.run(`
        CREATE TABLE IF NOT EXISTS reported_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT,
            subject TEXT,
            received TEXT
        )
    `);

    // Create the reviewed_phishing_emails table (emails flagged for review)
    db.run(`
        CREATE TABLE IF NOT EXISTS reviewed_phishing_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT,
            subject TEXT,
            received TEXT
        )
    `);

    // Function to insert email data with duplicate check
    const insertEmail = (email) => {
        const { sender, subject, received } = email;

        db.get("SELECT * FROM reported_emails WHERE subject = ? AND sender = ? AND received = ?", [subject, sender, received], (err, row) => {
            if (err) {
                console.error("Error checking for duplicate:", err);
                return;
            }

            if (row) {
                console.log("Duplicate email detected. Skipping insert.");
            } else {
                const query = "INSERT INTO reported_emails (sender, subject, received) VALUES (?, ?, ?)";
                db.run(query, [sender, subject, received], (err) => {
                    if (err) {
                        console.error("Error inserting email:", err);
                    } else {
                        console.log(`Email from ${sender} inserted successfully.`);
                    }
                });
            }
        });
    };

    const regularEmails = [
        { sender: "John Doe", subject: "Meeting Tomorrow", received: "2025-01-01 9:00 AM" },
        { sender: "Jane Smith", subject: "Project Update", received: "2025-01-01 10:15 AM" },
        { sender: "Michael Johnson", subject: "Invoice #12345", received: "2025-01-02 3:00 PM" }
    ];

    regularEmails.forEach(insertEmail);
});

module.exports = db;
